﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_Softwaretechnik
{
    public partial class Urlaub : Form
    {
        private Menue_Mitarbeiter f2;
        bool zurueckGeklickt = false;
        public Urlaub(Menue_Mitarbeiter form2)
        {
            InitializeComponent();
            f2 = form2;
        }

        private void Urlaub_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!zurueckGeklickt)
            {
                System.Windows.Forms.Application.Exit();

            }
        }

        private void kalender1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            zurueckGeklickt = true;
            f2.Show();
            Close();
        }

        private void Urlaub_Load(object sender, EventArgs e)
        {

        }

        private void Urlaub_FormClosed(object sender, FormClosedEventArgs e)
        {
            //Application.Exit();
        }
    }
}
