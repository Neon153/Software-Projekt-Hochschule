﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_Softwaretechnik
{
    public partial class Posteingang : Form
    {
        private Menue_Mitarbeiter f2;

        bool zurueckGeklickt = false;

        public Posteingang(Menue_Mitarbeiter form2)
        {
            InitializeComponent();
            f2 = form2;
        }

        private void BtnZurueck_Posteingang_Menue_Click(object sender, EventArgs e)
        {
            zurueckGeklickt = true;
            f2.Show();
            Close();
        }

        private void Posteingang_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!zurueckGeklickt)
            {
                System.Windows.Forms.Application.Exit();

            }
        }
    }
}
