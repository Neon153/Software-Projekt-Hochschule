﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_Softwaretechnik
{
    public partial class Menue_Mitarbeiter : Form
    {
        Login form1;
        Menue_Mitarbeiter form2;
        bool zurueckGeklickt = false;  // Variable, um zu überprüfen, ob "Abmelden" geklickt wurde
        public Menue_Mitarbeiter(Login f1)
        {
            InitializeComponent();
            form1 = f1;
            
        }

        private void abmelden_Click(object sender, EventArgs e)
        {
            zurueckGeklickt = true;
            form1.Show();
            this.Close();
            
        }

        private void time_Click(object sender, EventArgs e)
        {
            ein_und_ausstempeln form3 = new ein_und_ausstempeln(this);
            form3.Show();
            this.Hide();
        }

        private void krank_Click(object sender, EventArgs e)
        {
            Krankmelden krank = new Krankmelden(this);
            krank.Show();
            Hide();
        }

        private void urlaub_Click(object sender, EventArgs e)
        {
            Urlaub u = new Urlaub(this);
            u.Show();
            Hide();
        }

        private void posteingang_Click(object sender, EventArgs e)
        {
            Posteingang p = new Posteingang(this);
            p.Show();
            Hide();
        }

        private void Menue_Mitarbeiter_FormClosing(object sender, FormClosingEventArgs e)   // Ereignisbehandlung für das Schließen des Formulars
        {
            if (zurueckGeklickt == false)                                                   // Überprüfen, ob "Abmelden" nicht geklickt wurde
            {
                System.Windows.Forms.Application.Exit();                                    // Anwendung beenden, wenn das Formular geschlossen wird (nicht durch "Abmelden")

            }
        }
    }
}
