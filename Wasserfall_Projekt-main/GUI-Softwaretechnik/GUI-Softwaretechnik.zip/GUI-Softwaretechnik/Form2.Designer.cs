﻿namespace GUI_Softwaretechnik
{
    partial class Menue_Mitarbeiter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.abmelden = new System.Windows.Forms.Button();
            this.time = new System.Windows.Forms.Button();
            this.urlaub = new System.Windows.Forms.Button();
            this.krank = new System.Windows.Forms.Button();
            this.posteingang = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.PnlWeiss_Gleitzeit = new System.Windows.Forms.Panel();
            this.PnlGruen_Gleitzeit = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.PnlWeiss_Urlaub = new System.Windows.Forms.Panel();
            this.PnlGruen_Urlaub = new System.Windows.Forms.Panel();
            this.Kalender_Menu_Mitarbeiter = new Forms_Zeitmanagement.Kalender();
            this.Lbl_Infos_time = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // abmelden
            // 
            this.abmelden.Location = new System.Drawing.Point(662, 398);
            this.abmelden.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.abmelden.Name = "abmelden";
            this.abmelden.Size = new System.Drawing.Size(105, 37);
            this.abmelden.TabIndex = 0;
            this.abmelden.Text = "Abmelden";
            this.abmelden.UseVisualStyleBackColor = true;
            this.abmelden.Click += new System.EventHandler(this.abmelden_Click);
            // 
            // time
            // 
            this.time.Location = new System.Drawing.Point(32, 64);
            this.time.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(151, 50);
            this.time.TabIndex = 1;
            this.time.Text = "Ein und Ausstempeln";
            this.time.UseVisualStyleBackColor = true;
            this.time.Click += new System.EventHandler(this.time_Click);
            // 
            // urlaub
            // 
            this.urlaub.Location = new System.Drawing.Point(32, 119);
            this.urlaub.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.urlaub.Name = "urlaub";
            this.urlaub.Size = new System.Drawing.Size(151, 50);
            this.urlaub.TabIndex = 2;
            this.urlaub.Text = "Urlaub Beantragen";
            this.urlaub.UseVisualStyleBackColor = true;
            this.urlaub.Click += new System.EventHandler(this.urlaub_Click);
            // 
            // krank
            // 
            this.krank.Location = new System.Drawing.Point(32, 173);
            this.krank.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.krank.Name = "krank";
            this.krank.Size = new System.Drawing.Size(151, 50);
            this.krank.TabIndex = 3;
            this.krank.Text = "Krankmelden";
            this.krank.UseVisualStyleBackColor = true;
            this.krank.Click += new System.EventHandler(this.krank_Click);
            // 
            // posteingang
            // 
            this.posteingang.Location = new System.Drawing.Point(32, 228);
            this.posteingang.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.posteingang.Name = "posteingang";
            this.posteingang.Size = new System.Drawing.Size(151, 50);
            this.posteingang.TabIndex = 4;
            this.posteingang.Text = "Posteingang";
            this.posteingang.UseVisualStyleBackColor = true;
            this.posteingang.Click += new System.EventHandler(this.posteingang_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label10.Location = new System.Drawing.Point(610, 278);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 24);
            this.label10.TabIndex = 30;
            this.label10.Text = "30 h";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label9.Location = new System.Drawing.Point(610, 208);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 24);
            this.label9.TabIndex = 29;
            this.label9.Text = "5/10 h";
            // 
            // PnlWeiss_Gleitzeit
            // 
            this.PnlWeiss_Gleitzeit.BackColor = System.Drawing.Color.Snow;
            this.PnlWeiss_Gleitzeit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnlWeiss_Gleitzeit.Location = new System.Drawing.Point(634, 235);
            this.PnlWeiss_Gleitzeit.Name = "PnlWeiss_Gleitzeit";
            this.PnlWeiss_Gleitzeit.Size = new System.Drawing.Size(80, 15);
            this.PnlWeiss_Gleitzeit.TabIndex = 28;
            // 
            // PnlGruen_Gleitzeit
            // 
            this.PnlGruen_Gleitzeit.BackColor = System.Drawing.Color.Lime;
            this.PnlGruen_Gleitzeit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnlGruen_Gleitzeit.Location = new System.Drawing.Point(554, 235);
            this.PnlGruen_Gleitzeit.Name = "PnlGruen_Gleitzeit";
            this.PnlGruen_Gleitzeit.Size = new System.Drawing.Size(80, 15);
            this.PnlGruen_Gleitzeit.TabIndex = 27;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(321, 231);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(199, 24);
            this.label8.TabIndex = 26;
            this.label8.Text = "Gleitzeit diesen Monat:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(367, 278);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(149, 24);
            this.label7.TabIndex = 25;
            this.label7.Text = "Gleitzeit Gesamt:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(630, 385);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 24);
            this.label6.TabIndex = 24;
            this.label6.Text = "5";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(410, 385);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 24);
            this.label5.TabIndex = 23;
            this.label5.Text = "Kranktage:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(610, 318);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 24);
            this.label4.TabIndex = 22;
            this.label4.Text = "20/30";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(302, 338);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(214, 24);
            this.label3.TabIndex = 21;
            this.label3.Text = "Verfügbare Urlaubstage:";
            // 
            // PnlWeiss_Urlaub
            // 
            this.PnlWeiss_Urlaub.BackColor = System.Drawing.Color.Snow;
            this.PnlWeiss_Urlaub.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnlWeiss_Urlaub.Location = new System.Drawing.Point(654, 347);
            this.PnlWeiss_Urlaub.Name = "PnlWeiss_Urlaub";
            this.PnlWeiss_Urlaub.Size = new System.Drawing.Size(60, 15);
            this.PnlWeiss_Urlaub.TabIndex = 20;
            // 
            // PnlGruen_Urlaub
            // 
            this.PnlGruen_Urlaub.BackColor = System.Drawing.Color.Lime;
            this.PnlGruen_Urlaub.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnlGruen_Urlaub.Location = new System.Drawing.Point(554, 347);
            this.PnlGruen_Urlaub.Name = "PnlGruen_Urlaub";
            this.PnlGruen_Urlaub.Size = new System.Drawing.Size(100, 15);
            this.PnlGruen_Urlaub.TabIndex = 19;
            // 
            // Kalender_Menu_Mitarbeiter
            // 
            this.Kalender_Menu_Mitarbeiter.IsColorToggleEnabled = true;
            this.Kalender_Menu_Mitarbeiter.Location = new System.Drawing.Point(414, 12);
            this.Kalender_Menu_Mitarbeiter.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Kalender_Menu_Mitarbeiter.Name = "Kalender_Menu_Mitarbeiter";
            this.Kalender_Menu_Mitarbeiter.Size = new System.Drawing.Size(300, 193);
            this.Kalender_Menu_Mitarbeiter.TabIndex = 31;
            // 
            // Lbl_Infos_time
            // 
            this.Lbl_Infos_time.Location = new System.Drawing.Point(244, 36);
            this.Lbl_Infos_time.Name = "Lbl_Infos_time";
            this.Lbl_Infos_time.Size = new System.Drawing.Size(164, 78);
            this.Lbl_Infos_time.TabIndex = 45;
            this.Lbl_Infos_time.Text = "Durch Klicks auf Kalenderfläche sollen hier Infos (z.B. ein Ausstempelzeiten; Url" +
    "aub; ...) ausgegeben werden";
            // 
            // Menue_Mitarbeiter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 446);
            this.Controls.Add(this.Lbl_Infos_time);
            this.Controls.Add(this.Kalender_Menu_Mitarbeiter);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.PnlWeiss_Gleitzeit);
            this.Controls.Add(this.PnlGruen_Gleitzeit);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.PnlWeiss_Urlaub);
            this.Controls.Add(this.PnlGruen_Urlaub);
            this.Controls.Add(this.posteingang);
            this.Controls.Add(this.krank);
            this.Controls.Add(this.urlaub);
            this.Controls.Add(this.time);
            this.Controls.Add(this.abmelden);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Menue_Mitarbeiter";
            this.Text = "Menue Mitarbeiter";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Menue_Mitarbeiter_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button abmelden;
        private System.Windows.Forms.Button time;
        private System.Windows.Forms.Button urlaub;
        private System.Windows.Forms.Button krank;
        private System.Windows.Forms.Button posteingang;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel PnlWeiss_Gleitzeit;
        private System.Windows.Forms.Panel PnlGruen_Gleitzeit;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel PnlWeiss_Urlaub;
        private System.Windows.Forms.Panel PnlGruen_Urlaub;
        private Forms_Zeitmanagement.Kalender Kalender_Menu_Mitarbeiter;
        private System.Windows.Forms.Label Lbl_Infos_time;
    }
}