﻿namespace GUI_Softwaretechnik
{
    partial class Korrektur
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.correctur_calender = new System.Windows.Forms.MonthCalendar();
            this.date = new System.Windows.Forms.Label();
            this.choosedate = new System.Windows.Forms.DateTimePicker();
            this.back_to_ein_und_ausstemplen = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // correctur_calender
            // 
            this.correctur_calender.Location = new System.Drawing.Point(212, 81);
            this.correctur_calender.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.correctur_calender.MaxDate = new System.DateTime(2099, 12, 31, 0, 0, 0, 0);
            this.correctur_calender.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.correctur_calender.Name = "correctur_calender";
            this.correctur_calender.TabIndex = 1;
            this.correctur_calender.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.correctur_calender_DateChanged);
            this.correctur_calender.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.correctur_calender_DateSelected);
            // 
            // date
            // 
            this.date.AutoSize = true;
            this.date.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.date.Location = new System.Drawing.Point(249, 257);
            this.date.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(38, 17);
            this.date.TabIndex = 2;
            this.date.Text = "Date";
            // 
            // choosedate
            // 
            this.choosedate.Location = new System.Drawing.Point(212, 54);
            this.choosedate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.choosedate.MaxDate = new System.DateTime(2099, 12, 31, 0, 0, 0, 0);
            this.choosedate.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.choosedate.Name = "choosedate";
            this.choosedate.Size = new System.Drawing.Size(156, 20);
            this.choosedate.TabIndex = 3;
            this.choosedate.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // back_to_ein_und_ausstemplen
            // 
            this.back_to_ein_und_ausstemplen.Location = new System.Drawing.Point(486, 319);
            this.back_to_ein_und_ausstemplen.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.back_to_ein_und_ausstemplen.Name = "back_to_ein_und_ausstemplen";
            this.back_to_ein_und_ausstemplen.Size = new System.Drawing.Size(92, 33);
            this.back_to_ein_und_ausstemplen.TabIndex = 4;
            this.back_to_ein_und_ausstemplen.Text = "Zurück";
            this.back_to_ein_und_ausstemplen.UseVisualStyleBackColor = true;
            this.back_to_ein_und_ausstemplen.Click += new System.EventHandler(this.back_to_ein_und_ausstemplen_Click);
            // 
            // Korrektur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.back_to_ein_und_ausstemplen);
            this.Controls.Add(this.choosedate);
            this.Controls.Add(this.date);
            this.Controls.Add(this.correctur_calender);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Korrektur";
            this.Text = "korrektur";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Korrektur_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.MonthCalendar correctur_calender;
        private System.Windows.Forms.Label date;
        private System.Windows.Forms.DateTimePicker choosedate;
        private System.Windows.Forms.Button back_to_ein_und_ausstemplen;
    }
}