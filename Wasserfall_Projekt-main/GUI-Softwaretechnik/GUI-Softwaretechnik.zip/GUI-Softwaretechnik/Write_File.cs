﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUI_Softwaretechnik
{
    //Die Datein werden unter /bin/Debug angelegt
    internal class Write_File
    {
        private String[] username_password;
        public bool Create_Folder(String name)
        {
            if (Directory.Exists(name))
            {
                return true;
            }
            else if (!File.Exists(name))
            {
                Directory.CreateDirectory(name);
                return false;
            }
            return false;
        }
        public bool Delete_Folder(String name)
        {
            if (Directory.Exists(name))
            {
                Directory.Delete(name);
                return true;
            }
            else if (!File.Exists(name))
            {
                return false;
            }
            return false;
        }
        public void Write_In_File(String name, String inhalt)//Eventuell noch prüfen ob datei exestiert
        {
            File.AppendAllText(name, inhalt);
        }
        public void Delete_File(String name)//Eventuell noch prüfen ob datei exestiert
        {
            File.Delete(name);
        }
        public String[] Read_File(String name)//Eventuell noch prüfen ob datei exestiert
        {
            return File.ReadAllLines(name);
        }
    }
}
