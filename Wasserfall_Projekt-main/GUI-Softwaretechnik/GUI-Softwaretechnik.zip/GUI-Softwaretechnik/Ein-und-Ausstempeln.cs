﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_Softwaretechnik
{
    public partial class ein_und_ausstempeln : Form
    {
        Menue_Mitarbeiter f2;
        ein_und_ausstempeln f3;
        bool zurueckGeklickt = false;
        public ein_und_ausstempeln(Menue_Mitarbeiter form2)
        {
            InitializeComponent();
            DateTime t = DateTime.Now;
            show_Date.Text = t.ToString();
            f2 = form2;
        }


        private void back1_Click(object sender, EventArgs e)
        {   
            
            
            zurueckGeklickt = true;
            f2.Show();
            this.Close();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Work w1 = new Work(anfangszeit.Text, endzeit.Text);
            int start = w1.ConvertInTime(anfangszeit.Text);
            int end = w1.ConvertInTime(endzeit.Text);
            int diff = w1.CalcDiff(start, end);
            String workingtime = w1.ConvertInString(diff);
            workingtime1.Text = workingtime;
            workingtime1.Refresh();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Korrektur k1 = new Korrektur(this);
            k1.Show();
        }

        private void ein_und_ausstempeln_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!zurueckGeklickt)
            {
                System.Windows.Forms.Application.Exit();
            }
        }
    }
}
