﻿namespace GUI_Softwaretechnik
{
    partial class Posteingang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Pnl_Nachrichten = new System.Windows.Forms.Panel();
            this.Lbl_Nachrichten = new System.Windows.Forms.Label();
            this.BtnZurueck_Posteingang_Menue = new System.Windows.Forms.Button();
            this.Pnl_Nachrichten.SuspendLayout();
            this.SuspendLayout();
            // 
            // Pnl_Nachrichten
            // 
            this.Pnl_Nachrichten.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Pnl_Nachrichten.Controls.Add(this.Lbl_Nachrichten);
            this.Pnl_Nachrichten.Location = new System.Drawing.Point(130, 27);
            this.Pnl_Nachrichten.Name = "Pnl_Nachrichten";
            this.Pnl_Nachrichten.Size = new System.Drawing.Size(457, 376);
            this.Pnl_Nachrichten.TabIndex = 4;
            // 
            // Lbl_Nachrichten
            // 
            this.Lbl_Nachrichten.AutoSize = true;
            this.Lbl_Nachrichten.Location = new System.Drawing.Point(23, 24);
            this.Lbl_Nachrichten.Name = "Lbl_Nachrichten";
            this.Lbl_Nachrichten.Size = new System.Drawing.Size(120, 13);
            this.Lbl_Nachrichten.TabIndex = 1;
            this.Lbl_Nachrichten.Text = "hier stehen Nachrichten";
            // 
            // BtnZurueck_Posteingang_Menue
            // 
            this.BtnZurueck_Posteingang_Menue.Location = new System.Drawing.Point(626, 380);
            this.BtnZurueck_Posteingang_Menue.Name = "BtnZurueck_Posteingang_Menue";
            this.BtnZurueck_Posteingang_Menue.Size = new System.Drawing.Size(75, 23);
            this.BtnZurueck_Posteingang_Menue.TabIndex = 3;
            this.BtnZurueck_Posteingang_Menue.Text = "Zurück";
            this.BtnZurueck_Posteingang_Menue.UseVisualStyleBackColor = true;
            this.BtnZurueck_Posteingang_Menue.Click += new System.EventHandler(this.BtnZurueck_Posteingang_Menue_Click);
            // 
            // Posteingang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Pnl_Nachrichten);
            this.Controls.Add(this.BtnZurueck_Posteingang_Menue);
            this.Name = "Posteingang";
            this.Text = "Posteingang";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Posteingang_FormClosing);
            this.Pnl_Nachrichten.ResumeLayout(false);
            this.Pnl_Nachrichten.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Pnl_Nachrichten;
        private System.Windows.Forms.Label Lbl_Nachrichten;
        private System.Windows.Forms.Button BtnZurueck_Posteingang_Menue;
    }
}