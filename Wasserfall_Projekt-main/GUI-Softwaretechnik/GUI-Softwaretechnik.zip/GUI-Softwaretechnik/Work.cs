﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUI_Softwaretechnik
{
    internal class Work
    {
        private String start;
        private String end;
        public Work(String starttime, String endtime) {
            start=starttime;
            end=endtime;
        }

        public int ConvertInTime(String time){
            String hour=time.Substring(0,2);
            String minute=time.Substring(3);
            int hoursinminutes=int.Parse(hour);
            int minutes=int.Parse(minute);
            hoursinminutes = hoursinminutes * 60;
            int gesamtminuten = hoursinminutes + minutes;
            return gesamtminuten;
        }

        public int CalcDiff(int startAt, int endAt)
        {
            return endAt-startAt;
        }

        public String ConvertInString(int time)
        {
            int stunden = time / 60;
            int minuten = time % 60;
            String hourinstring = stunden.ToString();
            String minuteinstring = minuten.ToString();
            return hourinstring+"h"+":"+minuteinstring+"min";
        }
        //Moin Leute, wenn ihr das lesen könnt dann hab ich es hinbekommen mit Github
        //Anleitung wie es funktioniert hat.
        //1. änderung im code machen
        //2.bei Git-Änderungen eine Nachricht in das große Feld eintragen. Dann alle Committen auswählen.
        //Zu guter letzt pushen
        //https://learn.microsoft.com/de-de/visualstudio/version-control/git-push-remote?view=vs-2022
        //Test von Adrian der diese Zeile hinzufügt :D

        public String CorrectTime(String time)
        {
            return "";
        }
    }
}
