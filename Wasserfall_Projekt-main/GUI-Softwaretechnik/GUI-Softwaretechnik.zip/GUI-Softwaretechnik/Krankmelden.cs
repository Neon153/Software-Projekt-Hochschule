﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_Softwaretechnik
{
    public partial class Krankmelden : Form
    {
        private Krankheit k1 = new Krankheit();
        private Menue_Mitarbeiter f2;
        bool zurueckGeklickt = false;  

        public Krankmelden(Menue_Mitarbeiter form2)
        {
            InitializeComponent();
            f2 = form2;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime krankheitAnfang = anfang.Value;
            k1.SetAnfang(krankheitAnfang);
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            DateTime krankheitEnde = ende.Value;
            k1.SetEnde(krankheitEnde);
        }

        private void Bkrankheiteinreichen_Click(object sender, EventArgs e)
        {
            TimeSpan t1 = k1.diff();
            String krankTage = k1.convertToString(t1);
            KrankheitsTage.Text = krankTage.Substring(0, 2)+" Tage";
        }

        private void back_to_menue_Click(object sender, EventArgs e)
        {
            zurueckGeklickt = true;
            f2.Show();
            Close();
            
        }

        private void Krankmelden_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!zurueckGeklickt)
            {
                System.Windows.Forms.Application.Exit();

            }
        }

        private void Krankmelden_Load(object sender, EventArgs e)
        {

        }

        private void Krankmelden_FormClosed(object sender, FormClosedEventArgs e)
        {
            //Application.Exit();
        }
    }
}
