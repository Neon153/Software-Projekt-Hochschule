﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_Softwaretechnik
{
    public partial class Korrektur : Form
    {
        ein_und_ausstempeln f3;
        bool zurueckGeklickt = false; 
        public Korrektur(ein_und_ausstempeln form3)
        {
            InitializeComponent();
            f3 = form3;
        }

        private void correctur_calender_DateSelected(object sender, DateRangeEventArgs e)
        {
            
            
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime t = choosedate.Value;
            String time = t.ToString();
            correctur_calender.AddBoldedDate(t);
            date.Text = time;
            date.Refresh();
        }

        private void back_to_ein_und_ausstemplen_Click(object sender, EventArgs e)
        {   
            zurueckGeklickt = true;
            f3.Show();
            this.Close();
            
        }

        private void correctur_calender_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void Korrektur_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!zurueckGeklickt)
            {
                System.Windows.Forms.Application.Exit();

            }
        }
    }
}
