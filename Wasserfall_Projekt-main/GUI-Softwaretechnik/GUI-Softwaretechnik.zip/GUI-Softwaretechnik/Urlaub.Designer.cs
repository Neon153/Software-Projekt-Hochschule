﻿namespace GUI_Softwaretechnik
{
    partial class Urlaub
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.kalender1 = new Forms_Zeitmanagement.Kalender();
            this.backtomenue = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // kalender1
            // 
            this.kalender1.IsColorToggleEnabled = true;
            this.kalender1.Location = new System.Drawing.Point(100, 46);
            this.kalender1.Name = "kalender1";
            this.kalender1.Size = new System.Drawing.Size(387, 194);
            this.kalender1.TabIndex = 0;
            this.kalender1.Load += new System.EventHandler(this.kalender1_Load);
            // 
            // backtomenue
            // 
            this.backtomenue.Location = new System.Drawing.Point(476, 290);
            this.backtomenue.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.backtomenue.Name = "backtomenue";
            this.backtomenue.Size = new System.Drawing.Size(94, 38);
            this.backtomenue.TabIndex = 1;
            this.backtomenue.Text = "Zurück";
            this.backtomenue.UseVisualStyleBackColor = true;
            this.backtomenue.Click += new System.EventHandler(this.button1_Click);
            // 
            // Urlaub
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.backtomenue);
            this.Controls.Add(this.kalender1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Urlaub";
            this.Text = "Urlaub";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Urlaub_FormClosing);
            this.ResumeLayout(false);

        }

        #endregion

        private Forms_Zeitmanagement.Kalender kalender1;
        private System.Windows.Forms.Button backtomenue;
    }
}